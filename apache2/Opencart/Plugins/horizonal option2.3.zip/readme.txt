############################################################################################
if  you would like to Display Product Options Horizontally, especially for image,radio and checkout options.
this is your choice.

#############################################################################################

Module: horizontal option
Support: support@bestshop24h.com
Wechat:bestshop24h

Recommend a hosting who is special for opencart:http://www.a2hosting.com?aid=bestshop24h

if you are going to install the latest version of opencart which is 2.3.0.2,
justhost,bluehost or hostmonster are not good enough,they sometime have php version problem or sometime have mysql problem which conerns innodb_forced_recovery's setting.
and maybe there are still some other problem which would affect opencart funcation.
#############################################################################################
It has been tested ,and is  ok for opencart from 2.2 to 2.3.0.2.

Installation
1)backend>Extenstions>Extension installer,click upload file horizonal_option.ocmod.xml
2)backend>Extension>Modification,click "enable" button to install it,finally click "refresh" button on the top.
3)go to the frontend ,you will see the change.


note:
if you are not using the opencart default theme,you need to change the theme name in the file.

how to change?
1)please open file horizonal_option.ocmod.xml
find the following code
<file path="catalog/view/theme/default/template/product/product.tpl">

2)change "default" to your theme's name ,if your theme's name is "bestshop24h",then after changing,this code will become

<file path="catalog/view/theme/bestshop24h/template/product/product.tpl">

that is all. if you have any problem,please contact me : support@bestshop24h.com


yes,it is free extension,
anyway,if you feel it help you save some time,please donate 1 dollar to my best friend's PayPal: zhangchuanrui@live.com.

thanks,wish your business be successful!