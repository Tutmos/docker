<?php
// Heading
$_['heading_title']    = 'Sizechart';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified Sizechart module!';
$_['text_edit']        = 'Edit Sizechart module';

// Entry

$_['entry_status1']     = 'Size Chart Status';

// Help
$_['help_code']        = 'Goto <a href="https://developers.google.com/+/hangouts/button" target="_blank">Create a Google Hangout chatback badge</a> and copy &amp; paste the generated code into the text box.';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Sizechart module!';
$_['error_code']       = 'Text Required';