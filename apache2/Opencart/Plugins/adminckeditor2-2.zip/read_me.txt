Install:
Copy Vqmod folder to your root web folder. 


