/**
 * Created by alexw on 4/13/2015.
 */
CKEDITOR.plugins.setLang('extraformattributes', 'es', {
    idLabel: 'Identificación',
    classesLabel: 'Clases CSS',
    tabLabel: 'Opciones Aidcionales'
});