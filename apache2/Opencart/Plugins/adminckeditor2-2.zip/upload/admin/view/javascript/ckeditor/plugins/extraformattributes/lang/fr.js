/**
 * Created by alexw on 4/13/2015.
 */
CKEDITOR.plugins.setLang('extraformattributes', 'fr', {
    idLabel: 'd\'identité',
    classesLabel: 'Classes CSS',
    tabLabel: 'Options Supplémentaires'
});