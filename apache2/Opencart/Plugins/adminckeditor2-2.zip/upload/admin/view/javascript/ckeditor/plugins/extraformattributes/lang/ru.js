/**
 * Created by alexw on 4/13/2015.
 */
CKEDITOR.plugins.setLang('extraformattributes', 'ru', {
    idLabel: 'ID',
    classesLabel: 'CSS классы',
    tabLabel: 'Дополнительно'
});