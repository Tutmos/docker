/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'fo', {
	alt: 'Alternativur tekstur',
	btnUpload: 'Send til ambætaran',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'Myndaupplýsingar',
	lockRatio: 'Læs lutfallið',
	menu: 'Myndaeginleikar',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Upprunastødd',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Myndaeginleikar',
	uploadTab: 'Send til ambætaran',
	urlMissing: 'URL til mynd manglar.'
} );
