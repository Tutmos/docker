/*
Embedded document PDF, Office and many others format
via Google Docs Viewer iFrame
Author -vito-
http://opencartmodding.com/extensions/docsembedder
*/
CKEDITOR.plugins.setLang( 'docsembedder', 'en', {
	title: 'Embedded document properties',
	menubutton: 'Embedded document PDF, Office and many others format',
	contextmenu: 'Embedded document properties',
	emptyURL: 'URL field cannot be empty. Please fill it.'
} );
