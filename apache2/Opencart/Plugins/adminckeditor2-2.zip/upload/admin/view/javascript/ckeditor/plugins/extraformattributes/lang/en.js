/**
 * Created by alexw on 4/13/2015.
 */
CKEDITOR.plugins.setLang('extraformattributes', 'en', {
   idLabel: 'ID',
   classesLabel: 'CSS Classes',
   tabLabel: 'Extra Options'
});