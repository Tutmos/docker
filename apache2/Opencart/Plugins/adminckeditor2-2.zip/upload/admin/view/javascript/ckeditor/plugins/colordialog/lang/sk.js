/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'sk', {
	clear: 'Vyčistiť',
	highlight: 'Zvýrazniť',
	options: 'Možnosti farby',
	selected: 'Vybraná farba',
	title: 'Vybrať farbu'
} );
