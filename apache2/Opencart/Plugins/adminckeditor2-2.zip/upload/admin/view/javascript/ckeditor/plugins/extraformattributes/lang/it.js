/**
 * Created by alexw on 4/13/2015.
 */
CKEDITOR.plugins.setLang('extraformattributes', 'it', {
    idLabel: 'ID',
    classesLabel: 'Classi CSS',
    tabLabel: 'Opzioni extra'
});