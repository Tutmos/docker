/*
Embedded document PDF, Office and many others format
via Google Docs Viewer iFrame
Author -vito-
http://opencartmodding.com/extensions/docsembedder
*/
CKEDITOR.plugins.setLang( 'docsembedder', 'ru', {
	title: 'Свойства внедренного документа',
	menubutton: 'Внедрить документ PDF, Office и множество других форматов',
	contextmenu: 'Свойства внедренного документа',
	emptyURL: 'Поле ссылки не должно быть пустым. Пожалуйста заполните.'
} );
